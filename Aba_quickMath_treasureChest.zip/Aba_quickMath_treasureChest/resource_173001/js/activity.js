var quickMathsActivity = function(playerObj){
	var playerObj = playerObj;
	var that = this;
	var totalBoxes = 3;
	var totalQuestions = 5;
	var curQuestionNum = 1;
	var questionArr = [];
	var isAllDigitsShown = false;
	var buttonClickSound = ''; 
	var chestOpenSound = ''; 
	var chestCloseSound = ''; 
	var timerEndSound = '';
	var startScreenStage = '';
	var imageArr = [];
	var imageLoadCount = 0;
	var imagesPath = inner +'assets/images/';
	var isIPAD = (/iPad|iPhone/i.test(navigator.userAgent)); // IPAD
	var isAndroid = navigator.userAgent.toLowerCase().indexOf("android") > -1; //&& ua.indexOf("mobile");
	var isMac = (navigator.appVersion.indexOf("Mac") != -1);
		
	this.init = function(){
		console.log('Activity init() called');
		
		questionArr = playerObj.activityData.activityScreen.questionArr;
		totalQuestions = questionArr.length;
		
		buttonClickSound = inner + playerObj.activityData.resourceAudioPath + playerObj.activityData.soundArr[0];
		chestOpenSound = inner + playerObj.activityData.resourceAudioPath + playerObj.activityData.soundArr[1];
		chestCloseSound = inner + playerObj.activityData.resourceAudioPath + playerObj.activityData.soundArr[2];
		timerEndSound = inner + playerObj.activityData.resourceAudioPath + playerObj.activityData.soundArr[3];
		
		that.audioSrcArr = [buttonClickSound,chestOpenSound,chestCloseSound];
		that.audioEleArr = [$("#activityButtonClick"),$("#chestOpenSound"),$("#chestCloseSound")];
		
		playerObj.audioObj.loadAudio(that.audioEleArr,that.audioSrcArr);
		
		that.setStartScreenContent();
		
		$("#startBtn").off('click').on('click',that.setActivityScreenContent);
		//$("#partitionBtn").off('click').on('click',that.onShowPartitionBtnClick);
		$("#digitsBtn").off('click').on('click',that.onShowAllDigitsBtnClick);
		$("#quesPrevBtn").off('click').on('click',that.onPreviousBtnClick);
		$("#quesNextBtn").off('click').on('click',that.onNextBtnClick);
		console.log(playerObj.activityData)
	}
	
	this.getCorrectString = function(curStr){
		var curStr1 = String(curStr).replace('·','.');
		curStr1 = curStr1.replace('&middot;','.');
		
		if(curStr1.indexOf('£') > -1){
			curStr1 = curStr1.replace('£','');
			curStr1 = curStr1 + ' pound';
		}
		
		//console.log(curStr1);
		
		return curStr1;
	}
	
	this.setStartScreenContent = function(){
		$("#gameName").html(playerObj.activityData.startScreen.gameName);	
		$("#topicName").html(playerObj.activityData.startScreen.gameTopic);	
		//$(".heart-text").html(playerObj.activityData.startScreen.numberArr[0]);
		$("#bubbletText1").html(playerObj.activityData.startScreen.bubbleText1);
		
		if(isIPAD || isAndroid || isMac){
            var curTop = parseInt( $(".bubble-1-text").css('marginTop') ) + 2;
            $(".bubble-1-text").css('margin-top',curTop+'px');
        }
		
		if(isIPAD || isAndroid || isMac){
			//$(".silver-opened-text,.gold-opened-text").css('top','43px');
			$(".silver-closed-text, .silver-opened-text").css('padding-top','6px');
			$(".gold-closed-text, .gold-opened-text").css('padding-top','8px');
		}
		
		if(playerObj.activityData.startScreen.chestType == "gold"){
			$(".silver-chest").hide();
			$(".gold-chest").show();
			$(".gold-chest .gold-closed-text").html(playerObj.activityData.startScreen.numberArr[0]);
			$(".gold-chest .gold-opened-text").html(playerObj.activityData.startScreen.numberArr[1]);
		}else{
			$(".silver-chest").show();
			$(".gold-chest").hide();
			$(".silver-chest .silver-closed-text").html(playerObj.activityData.startScreen.numberArr[0]);
			$(".silver-chest .silver-opened-text").html(playerObj.activityData.startScreen.numberArr[1]);
		}
		
		$(".start-screen-chests").attr('aria-hidden',true);
		
		var curNum1 = that.getCorrectString( String( playerObj.activityData.startScreen.numberArr[0] ) );	
		var curNum2 = that.getCorrectString( String( playerObj.activityData.startScreen.numberArr[1] ) );

		$(".start-bubble-1").after("<span class='sr-only'>Activity shows a closed chest with number "+curNum1+" and an open chest filled with gold coins and gems with a number "+curNum2+" on a coin.  </span>");
	}
	
	this.getChestAltText = function(curIndex){
		var curAltText = ''
		
		if(questionArr[curQuestionNum-1].chestsArr[curIndex].className == "chest_silver" || questionArr[curQuestionNum-1].chestsArr[curIndex].className == "chest_silver_big" ){
			if(questionArr[curQuestionNum-1].revealStatusArr[curIndex] == false){
				curAltText = ' a silver-edged chest with number ';
			}else{
				curAltText = ' open chests filled with gold coins and gems with a number ';
			}
		}else if(questionArr[curQuestionNum-1].chestsArr[curIndex].className == "chest_gold" || questionArr[curQuestionNum-1].chestsArr[curIndex].className == "chest_gold_big" ){
			if(questionArr[curQuestionNum-1].revealStatusArr[curIndex] == false){
				curAltText = ' a gold-edged chest with number ';
			}else{
				curAltText = ' open chests filled with gold coins and gems with a number ';
			}
		}
		
		return curAltText;
	}
	
	this.createDynamicAltTexts1 = function(){
		var silverEdgedCount = 0;
		var goldEdgedCount = 0;
		var dynStr = '';
		var dynStr1 = ' ';
		var dynStr2 = '';
		var dynStr3 = '';
		for(var i=0;i<questionArr[curQuestionNum-1].chestsArr.length;i++){
			if(questionArr[curQuestionNum-1].chestsArr[i].className == "chest_silver" || questionArr[curQuestionNum-1].chestsArr[i].className == "chest_silver_big" ){
				silverEdgedCount++;
				dynStr2 += ' a silver-edged chest with number '+that.getCorrectString( questionArr[curQuestionNum-1].num1Arr[i] );
				dynStr3 += that.getCorrectString( questionArr[curQuestionNum-1].num1Arr[i] );
			}
			
			if(questionArr[curQuestionNum-1].chestsArr[i].className == "chest_gold" || questionArr[curQuestionNum-1].chestsArr[i].className == "chest_gold_big" ){
				goldEdgedCount++;
				dynStr2 += ' a gold-edged chest with number '+that.getCorrectString( questionArr[curQuestionNum-1].num1Arr[i] );
				dynStr3 += that.getCorrectString( questionArr[curQuestionNum-1].num1Arr[i] );
			}
			
			if(i == questionArr[curQuestionNum-1].chestsArr.length-1){
				dynStr2 += '.'
				dynStr3 += '.'
			}else{
				dynStr2 += ','
				dynStr3 += ','
			}
		}
		
		if( (silverEdgedCount == 0) && (goldEdgedCount > 0) ){
			dynStr1 += goldEdgedCount + ' gold-edged chests. The number on them, from left to right, top to bottom, are as follows: '
			dynStr = dynStr1 + dynStr3;
		}
		
		if( (goldEdgedCount == 0) && (silverEdgedCount > 0) ){
			dynStr1 += silverEdgedCount + ' silver-edged chests. The number on them, from left to right, top to bottom, are as follows: '
			dynStr = dynStr1 + dynStr3;
		}
		
		if( (goldEdgedCount > 0) && (silverEdgedCount > 0) ){
			dynStr1 += questionArr[curQuestionNum-1].chestsArr.length + ' chests,'+goldEdgedCount+' gold-edged and '+silverEdgedCount+' silver edged. The types of chests and the number on them, from left to right, top to bottom, are as follows: '
			dynStr = dynStr1 + dynStr2;
		}

		return dynStr;
	}
	
	
	this.createDynamicAltTexts2 = function(){
		var dynStr = questionArr[curQuestionNum-1].chestsArr.length + ' open chests filled with gold coins and gems with a number on a coin. The number on the coins on each chest shown in the opened chest from left to right, top to bottom, are as follows: ' 
		
		for(var i=0;i<questionArr[curQuestionNum-1].chestsArr.length;i++){
			
			dynStr+= that.getCorrectString( questionArr[curQuestionNum-1].ansArr[i] );
			
			if(i == questionArr[curQuestionNum-1].chestsArr.length-1){
				dynStr += '.'
			}else{
				dynStr += ','
			}
		}
		
		return dynStr;
	}
	
	this.setActivityScreenContent = function(){
		$("#startScreen").hide();
		$("#activityScreen").show();
		playerObj.audioObj.playAudio(that.audioEleArr[0]);
		$("#instructionText").html(playerObj.activityData.activityScreen.instructionText);
		that.setQuestion();
		//that.createStars();
	}
	
	this.createTreasureChests = function(){
		var tmpStr = '';	
		
		for(var i=0;i<questionArr[curQuestionNum-1].chestsArr.length;i++){
			//tmpStr+='<button style="top:'+questionArr[curQuestionNum-1].chestsArr[i].top+';left:'+questionArr[curQuestionNum-1].chestsArr[i].left+'"		class="'+questionArr[curQuestionNum-1].chestsArr[i].className+' chest"><div class=""><img class="chest_closed" alt="" src="'+imagesPath+questionArr[curQuestionNum-1].chestsArr[i].className+'_closed_frame_0.png" /><img class="chest_closed_hover" alt="" src="'+imagesPath+questionArr[curQuestionNum-1].chestsArr[i].className+'_closed_frame_1.png" /><img class="chest_opened" alt="" src="'+imagesPath+questionArr[curQuestionNum-1].chestsArr[i].className+'_opened_frame_0.png" /><img class="chest_opened_hover" alt="" src="'+imagesPath+questionArr[curQuestionNum-1].chestsArr[i].className+'_opened_frame_1.png" /><span class="num1"><span></span></span><span class="ans"></span></div></button>'

			tmpStr+='<button style="top:'+questionArr[curQuestionNum-1].chestsArr[i].top+'px;left:'+questionArr[curQuestionNum-1].chestsArr[i].left+'px"		class="'+questionArr[curQuestionNum-1].chestsArr[i].className+' chest"><img class="chest_closed" alt="" src="'+imagesPath+questionArr[curQuestionNum-1].chestsArr[i].className+'_closed_frame_0.png" /><img class="chest_closed_hover" alt="" src="'+imagesPath+questionArr[curQuestionNum-1].chestsArr[i].className+'_closed_frame_1.png" /><img class="chest_opened" alt="" src="'+imagesPath+questionArr[curQuestionNum-1].chestsArr[i].className+'_opened_frame_0.png" /><img class="chest_opened_hover" alt="" src="'+imagesPath+questionArr[curQuestionNum-1].chestsArr[i].className+'_opened_frame_1.png" /><span aria-hidden="true" class="num1"><span></span></span><span aria-hidden="true" class="ans"></span><span class="sr-only"></span></button>'
		}
		
		$(".chests-container").html(tmpStr);
		
		$(".chests-container .chest img").hide();
		$(".chests-container .chest .chest_closed").show();
		
		if(isIPAD || isAndroid || isMac){
			$(".num1 span").css('padding-top','4px');
			$(".chest_gold .ans").css('top','54px');
			$(".chest_silver .ans").css('top','58px');
			
			$(".chest_gold_big .ans").css('top','52px');
			$(".chest_silver_big .ans").css('top','52px');
			//$(".chest .frac span.bottom").css('padding-top','4px');
		}
		
		//$(".chests-container .chest").css({width:questionArr[curQuestionNum-1].buttonOpenDimension.width+"px",height:questionArr[curQuestionNum-1].buttonOpenDimension.height+"px"});
		
		$('button').on('mousedown mouseup',function(e){
			if (($(this).is(":focus") || $(this).is(e.target) || $(this).is(e.currentTarget)) && $(this).css("outline-style") == "none") {                    
              $(this).css("outline", "none").on("blur", function() {
                  $(this).off("blur").css("outline", "");
              });
			}
		});
	}
	
	this.setQuestion = function(){
		//$("#quesNum").html('<p>'+curQuestionNum+'/'+totalQuestions+'</p>');
		var curAltText = that.createDynamicAltTexts1();
		if(totalQuestions > 1){
			$("#dynamicContent").html(playerObj.activityData.activityScreen.instructionText + curAltText+' Page '+curQuestionNum+' of '+totalQuestions+'. ');
		}else{
			$("#dynamicContent").html(playerObj.activityData.activityScreen.instructionText + curAltText);
		}
		that.createTreasureChests();
		that.setPageNumber();
		that.setButtonStates();
		for(var i=0;i<questionArr[curQuestionNum-1].revealStatusArr.length;i++){
			if(questionArr[curQuestionNum-1].revealStatusArr[i] == false){
				
				var curLeft = questionArr[curQuestionNum-1].chestsArr[i].left;
				var curTop = questionArr[curQuestionNum-1].chestsArr[i].top;
				
				$(".activity-screen .chest:eq("+i+")").css('left',curLeft+'px');
				$(".activity-screen .chest:eq("+i+")").css('top',curTop+'px');
				
				$(".activity-screen .chest:eq("+i+") .num1 span").html(questionArr[curQuestionNum-1].num1Arr[i]).show();
				$(".activity-screen .chest:eq("+i+") .ans").html(questionArr[curQuestionNum-1].ansArr[i]).hide();
				$(".activity-screen .chest:eq("+i+") > .sr-only").html( that.getChestAltText(i) + that.getCorrectString(questionArr[curQuestionNum-1].num1Arr[i]) );
				$(".activity-screen .chest:eq("+i+")").removeClass('opened');
				$(".activity-screen .chest:eq("+i+")").find('img').hide();
				$(".activity-screen .chest:eq("+i+")").find('.chest_closed').show();
			}else{
				var diffX = questionArr[curQuestionNum-1].chestsArr[i].diffX;
				var diffY = questionArr[curQuestionNum-1].chestsArr[i].diffY;
				
				var curLeft = questionArr[curQuestionNum-1].chestsArr[i].left - (diffX/2);
				var curTop = questionArr[curQuestionNum-1].chestsArr[i].top - (diffY/2);
				
				$(".activity-screen .chest:eq("+i+")").css('left',curLeft+'px');
				$(".activity-screen .chest:eq("+i+")").css('top',curTop+'px');
				
				$(".activity-screen .chest:eq("+i+") .num1 span").html(questionArr[curQuestionNum-1].num1Arr[i]).hide();
				$(".activity-screen .chest:eq("+i+") .ans").html(questionArr[curQuestionNum-1].ansArr[i]).show();
				$(".activity-screen .chest:eq("+i+") > .sr-only").html( that.getChestAltText(i) + that.getCorrectString(questionArr[curQuestionNum-1].ansArr[i])  + ' on a coin ' );
				$(".activity-screen .chest:eq("+i+")").addClass('opened');
				$(".activity-screen .chest:eq("+i+")").find('img').hide();
				$(".activity-screen .chest:eq("+i+")").find('.chest_opened').show();
			}
		}
		$(".activity-screen .chest").off('click').on('click',that.onChestBtnClick);
		$(".activity-screen .chest").off('mouseover').on('mouseover',that.onChestBtnOver);
		$(".activity-screen .chest").off('mouseout').on('mouseout',that.onChestBtnOut);
		
		$(".chest .num1 .mixed-frac").each(function(){
			$(this).parents(".num1 > span:eq(0)").css({'background':'none','border':'none'});
		});
		
		if(isIPAD || isAndroid || isMac){
			$(".chest .frac span.bottom").css('padding-top','4px');
			$(".chest .mixed-frac").css('top','-8px');
			
			$(".chest .num1 .frac").css('top','3px');
			$(".chest .num1 .mixed-frac").height(43);
		}
		
		that.checkShowAnswerBtn();

	}
	
	this.onChestBtnOver = function(){
		var curIndex = $(this).index();
		if( $(this).hasClass('opened') ){
			$(this).find('img').hide();
			$(this).find('.chest_opened_hover').show();
		}else{
			$(this).find('img').hide();
			$(this).find('.chest_closed_hover').show();
		}	
	}
	
	this.onChestBtnOut = function(){
		var curIndex = $(this).index();
		if( $(this).hasClass('opened') ){
			$(this).find('img').hide();
			$(this).find('.chest_opened').show();
		}else{
			$(this).find('img').hide();
			$(this).find('.chest_closed').show();
		}	
	}
	
	this.onNextBtnClick = function(){
		if(curQuestionNum < totalQuestions){
			curQuestionNum++;
			playerObj.audioObj.playAudio(that.audioEleArr[0]);
			that.setQuestion();
		}
	}
	
	this.onPreviousBtnClick = function(){
		if(curQuestionNum > 1){
			curQuestionNum--;
			playerObj.audioObj.playAudio(that.audioEleArr[0]);
			that.setQuestion();
		}
	}
	
	this.setPageNumber = function(){
		$("#quesNum").html('<p>'+curQuestionNum+'/'+totalQuestions+'</p>');	

		if(isIPAD || isAndroid || isMac){
			$(".ques-num p").css('padding-top','10px');
		}
	}
	
	this.setButtonStates = function(){
		if(totalQuestions == 1){
			$(".ques-nav-btns").hide();
		}else if(curQuestionNum == 1){
			$("#quesPrevBtn").attr('disabled','disabled').css({'opacity':0.5,cursor:'default',pointerEvents:'none'});
			$("#quesNextBtn").removeAttr('disabled').css({'opacity':1,cursor:'pointer',pointerEvents:'auto'});
		}else if(curQuestionNum == totalQuestions){
			$("#quesNextBtn").attr('disabled','disabled').css({'opacity':0.5,cursor:'default',pointerEvents:'none'});
			$("#quesPrevBtn").removeAttr('disabled').css({'opacity':1,cursor:'pointer',pointerEvents:'auto'});
		}else{
			$("#quesPrevBtn").removeAttr('disabled').css({'opacity':1,cursor:'pointer',pointerEvents:'auto'});
			$("#quesNextBtn").removeAttr('disabled').css({'opacity':1,cursor:'pointer',pointerEvents:'auto'});
		}
	}
	
	this.onShowAllDigitsBtnClick = function(){
		console.log(isAllDigitsShown);
		if(!isAllDigitsShown){
			isAllDigitsShown = true;
			playerObj.audioObj.playAudio(that.audioEleArr[1]);
			for(var i=0;i<questionArr[curQuestionNum-1].revealStatusArr.length;i++){
				
				var diffX = questionArr[curQuestionNum-1].chestsArr[i].diffX;
				var diffY = questionArr[curQuestionNum-1].chestsArr[i].diffY;
				
				var curLeft = questionArr[curQuestionNum-1].chestsArr[i].left - (diffX/2);
				var curTop = questionArr[curQuestionNum-1].chestsArr[i].top - (diffY/2);
			
				$(".activity-screen .chest:eq("+i+")").css('left',curLeft+'px');
				$(".activity-screen .chest:eq("+i+")").css('top',curTop+'px');
				
				$(".activity-screen .chest").addClass('opened');
				$(".activity-screen .chest .num1").hide();
				$(".activity-screen .chest .ans").show();
				$(".activity-screen .chest:eq("+i+")").find('img').hide();
				$(".activity-screen .chest:eq("+i+")").find('.chest_opened').show();
				questionArr[curQuestionNum-1].revealStatusArr[i] = true;
				
				$(".activity-screen .chest:eq("+i+") > .sr-only").html( that.getChestAltText(i) + that.getCorrectString(questionArr[curQuestionNum-1].ansArr[i]) + ' on a coin ');
			}
			var curAltText = that.createDynamicAltTexts2();
			$("#dynamicContent").html(curAltText);
			that.changeShowAllBtnText("Hide all answers");
		}else{
			isAllDigitsShown = false;
			playerObj.audioObj.playAudio(that.audioEleArr[2]);
			for(var i=0;i<questionArr[curQuestionNum-1].revealStatusArr.length;i++){

				var curLeft = questionArr[curQuestionNum-1].chestsArr[i].left;
				var curTop = questionArr[curQuestionNum-1].chestsArr[i].top;
								
				$(".activity-screen .chest:eq("+i+")").css('left',curLeft+'px');
				$(".activity-screen .chest:eq("+i+")").css('top',curTop+'px');
				
				$(".activity-screen .chest").removeClass('opened');
				$(".activity-screen .chest .num1").show();
				$(".activity-screen .chest .ans").hide();
				$(".activity-screen .chest:eq("+i+")").find('img').hide();
				$(".activity-screen .chest:eq("+i+")").find('.chest_closed').show();
				questionArr[curQuestionNum-1].revealStatusArr[i] = false;
				
				$(".activity-screen .chest:eq("+i+") > .sr-only").html( that.getChestAltText(i) + that.getCorrectString(questionArr[curQuestionNum-1].num1Arr[i]) );
			}
			var curAltText = that.createDynamicAltTexts1();
			$("#dynamicContent").html(curAltText);
			that.changeShowAllBtnText("Show all answers");
		}
	}
		
	this.changeShowAllBtnText = function(curText){
		$("#digitsBtn").html(curText);
	}
	
	this.checkShowAnswerBtn = function(){
		var revealCount = 0;
		for(var i=0;i<questionArr[curQuestionNum-1].revealStatusArr.length;i++){
			var isRevealed = questionArr[curQuestionNum-1].revealStatusArr[i];
			if(isRevealed){
				revealCount++;
			}
		}
	
		if(revealCount == questionArr[curQuestionNum-1].revealStatusArr.length){
			isAllDigitsShown = true;
			that.changeShowAllBtnText("Hide all answers");
		}else{
			isAllDigitsShown = false;
			that.changeShowAllBtnText("Show all answers");
		}
	}
	
	this.onChestBtnClick = function(e){

		var curIndex = $(this).index();
		
			
		if(questionArr[curQuestionNum-1].revealStatusArr[curIndex] == false){
			questionArr[curQuestionNum-1].revealStatusArr[curIndex] = true;
			playerObj.audioObj.playAudio(that.audioEleArr[1]);
			
			var diffX = questionArr[curQuestionNum-1].chestsArr[curIndex].diffX;
			var diffY = questionArr[curQuestionNum-1].chestsArr[curIndex].diffY;
			
			var curLeft = questionArr[curQuestionNum-1].chestsArr[curIndex].left - (diffX/2);
			var curTop = questionArr[curQuestionNum-1].chestsArr[curIndex].top - (diffY/2);
			
			$(this).css('left',curLeft+'px');
			$(this).css('top',curTop+'px');
			
			$(this).find('img').hide();
			$(this).find('.chest_opened').show();
			$(this).addClass('opened');
			$(this).find('.ans').show();
			$(this).find('.num1').hide();
			$("#dynamicContent").html(that.getChestAltText(curIndex) + that.getCorrectString(questionArr[curQuestionNum-1].ansArr[curIndex]) + ' on a coin ' );
			
			$(".activity-screen .chest:eq("+curIndex+") > .sr-only").html(that.getChestAltText(curIndex) +  that.getCorrectString(questionArr[curQuestionNum-1].ansArr[curIndex])+ ' on a coin ' );
		}else{
			questionArr[curQuestionNum-1].revealStatusArr[curIndex] = false;
			playerObj.audioObj.playAudio(that.audioEleArr[2]);

			var curLeft = questionArr[curQuestionNum-1].chestsArr[curIndex].left;
			var curTop = questionArr[curQuestionNum-1].chestsArr[curIndex].top;
			
			$(this).css('left',curLeft+'px');
			$(this).css('top',curTop+'px');
			
			$(this).find('img').hide();
			$(this).find('.chest_closed').show();
			$(this).removeClass('opened');
			$(this).find('.ans').hide();
			$(this).find('.num1').show();
			//console.log( $(this).find('.ans') );
			$("#dynamicContent").html(that.getChestAltText(curIndex) + that.getCorrectString(questionArr[curQuestionNum-1].num1Arr[curIndex]) );
						
			$(".activity-screen .chest:eq("+curIndex+") > .sr-only").html(that.getChestAltText(curIndex) +  that.getCorrectString(questionArr[curQuestionNum-1].num1Arr[curIndex]) );
			//$(this).html(questionArr[curQuestionNum-1].hiddenTextArr[curIndex]);
		}
		
		that.checkShowAnswerBtn();
	}
}