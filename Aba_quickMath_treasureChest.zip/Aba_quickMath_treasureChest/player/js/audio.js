var AudioPlayer = function(){
	var that = this;
	var $prevAudio = null;
	var $prevAudio2 = null;
		
	this.init = function(){
		that.isAudioMuted = false;
	}
	
	this.loadAudio = function(eleArr,sourceArr){
		for(var i=0;i<eleArr.length;i++){
			$(eleArr[i]).attr('src',sourceArr[i]);
			$(eleArr[i]).load();	
		}
	}
			
	this.playAudio = function($audioEle){
		if($prevAudio != null){
			$prevAudio[0].pause();
			try{
				$prevAudio[0].currentTime = 0;
			}catch(e){
				
			}
		}
		console.log('Play audio');
		$audioEle[0].play();
		$prevAudio = $audioEle;
	}
	
	this.playAudio2 = function($audioEle2){
		if($prevAudio2 != null){
			$prevAudio2[0].pause();
			try{
				$prevAudio2[0].currentTime = 0;
			}catch(e){
				
			}
		}
		$audioEle2[0].play();
		$prevAudio2 = $audioEle2;
	}
	
	this.pauseAllAudio = function(){
		console.log('Pause audio called');
		var audioElArr = $(".audio-element");	
		for(var i=0;i<audioElArr.length;i++){
			$(audioElArr[i])[0].pause();
			try{
				$(audioElArr[i])[0].currentTime = 0;
			}catch(e){
				
			}
		}
	}
	
	this.muteAudio = function(){
		var audioElArr = $(".audio-element");
		for(var i=0;i<audioElArr.length;i++){
			$(audioElArr[i])[0].muted = true;
		}
		that.isAudioMuted = true;
	}
	
	this.unMuteAudio = function(){
		var audioElArr = $(".audio-element");
		console.log(audioElArr);
		for(var i=0;i<audioElArr.length;i++){
			//console.log( $(audioElArr[i])[0].muted );
			$(audioElArr[i])[0].muted = false;
			//audioElArr[i][0].muted = false;
		}
		that.isAudioMuted = false;
	}
}	