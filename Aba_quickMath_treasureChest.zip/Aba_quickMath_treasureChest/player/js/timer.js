var Timer = function(playerObj){
	
	var that = this;
	
	var isIPAD = (/iPad|iPhone/i.test(navigator.userAgent)); // IPAD
	var isAndroid = navigator.userAgent.toLowerCase().indexOf("android") > -1; //&& ua.indexOf("mobile");
	var isMac = (navigator.appVersion.indexOf("Mac") != -1);
	
	that.isTimerShown = false;
	that.timerDuration = 10;
	that.timerIntervalID = "";
	that.isTimerStarted = false;
	that.selectedIndex = 8;
	that.remainingMinutes = 10;
	that.remainingSeconds = 60;
	that.isPlayBtnDisabled = false;
	
	var htmlOptions = [
						"<span aria-hidden='true'>2:00</span><span class='sr-only'>2 Minutes</span>",
						"<span aria-hidden='true'>3:00</span><span class='sr-only'>3 Minutes</span>",
						"<span aria-hidden='true'>4:00</span><span class='sr-only'>4 Minutes</span>",
						"<span aria-hidden='true'>5:00</span><span class='sr-only'>5 Minutes</span>",
						"<span aria-hidden='true'>6:00</span><span class='sr-only'>6 Minutes</span>",
						"<span aria-hidden='true'>7:00</span><span class='sr-only'>7 Minutes</span>",
						"<span aria-hidden='true'>8:00</span><span class='sr-only'>8 Minutes</span>",
						"<span aria-hidden='true'>9:00</span><span class='sr-only'>9 Minutes</span>",
						"<span aria-hidden='true'>10:00</span><span class='sr-only'>10 Minutes</span>"
					   ];
	
	this.init = function(){
		that.$timer = $("#timer");
		that.$timerStartBtn = $("#timerStartBtn");
		that.$timerResetBtn = $("#timerResetBtn");
		that.$timerDropDown = $("#timerDropDown");
		that.$timerDropDown.val('10:00');
		

		that.$timerStartBtn.off('click').on('click',that.onTimerStartBtnClick)
						   .off('mouseover').on('mouseover',that.onTimerStartBtnHover)
						   .off('mouseout').on('mouseout',that.onTimerStartBtnOut);

		that.$timerResetBtn.off('click').on('click',that.onTimerResetBtnClick)
						   .off('mouseover').on('mouseover',that.onTimerResetBtnHover)
						   .off('mouseout').on('mouseout',that.onTimerResetBtnOut);
		
		//that.$timerDropDown.find('.dropdown-menu li').on('click keyup',that.onTimerDropDownChange);
		//that.$timerDropDown.find('.dropdown-menu li').on('keypress',that.onTimerDropDownChange);
						   
		that.$timerDropDown.off('change').on('change',that.onTimerDropDownChange)
						   .off('click').on('click',that.onTimerDropDownClick)
						   .off('mousedown').on('mousedown',that.onTimerMouseDownClick);
		
		/* $("#timerDropDown option").off('keydown').on('keydown',function(e){
			//e.preventDefault();
			e.stopPropagation();
			console.log( $(this).text() );
		}); */

		
		/* $('.dropdown').on('keydown.bs.dropdown.data-api', function(e) {
			console.log('keypress');
			console.log(e.target);
		}); */
		
		if(isMac || isIPAD || isAndroid){
			$("#timer-button").css('padding-top','11px');
			$("#option-list li").css('padding-top','6px');
		}
		
		if(!isIPAD && !isAndroid){
			$("#option-list li").off('mouseover').on('mouseover',that.onTimerOptionOver);
			$("#option-list li").off('mouseout').on('mouseout',that.onTimerOptionOut);
		}
	}
	
	this.onTimerOptionOver = function(){
		$("#option-list li").removeClass('hover');	
		$(this).addClass('hover');
	}
	
	this.onTimerOptionOut = function(){
		$("#option-list li").removeClass('hover');			
	}
	
	this.onTimerMouseDownClick = function(e){
		if(that.isTimerStarted || that.isPlayBtnDisabled){
			//e.preventDefault();
		}
	}
	
	this.onTimerDropDownChange = function(e){
		console.log('Drop down select');
		//console.log( e.keyCode );
		/* if(e.keyCode == 32 || e.keyCode == 13 ){
			$("#dropdownMenuButton").dropdown('hide')
		}
		that.$timerDropDown.find('.dropdown-toggle').html( $(this).text() ); */
		
		var options = ["2:00","3:00","4:00","5:00","6:00","7:00","8:00","9:00","10:00"];
		$("#timerDropDown option").each(function(index){
			$(this).text(options[index]);			
		});
		
		
		$("#option-list li").each(function(index){
			$(this).html(htmlOptions[index]);			
		});
		
		//that.selectedIndex = $("#timerDropDown").prop('selectedIndex');
		that.selectedIndex = Number( $("#option-list li[aria-selected='true']").attr('id').split('_')[1] ) - 1;
		clearInterval(that.timerIntervalID);
		that.$timerStartBtn.find('img').attr('src','assets/images/play_btn.png');
		that.$timerStartBtn.find('.timer-start-text').html('Start');
		that.isTimerStarted = false;
		
		that.remainingSeconds = 60;
		
		//$("#dynamicContent").html(parseInt(options[that.selectedIndex])+' Minutes');
		
		playerObj.audioObj.playAudio(playerObj.audioEleArr[0]);
		that.$timerStartBtn.attr('aria-pressed',false);
		that.$timerStartBtn.removeAttr('disabled');
		that.$timerStartBtn.css('opacity',1);
	}
	
	this.onTimerDropDownClick = function(e){
		console.log('Drop down click');	
		if(!that.isTimerStarted){
			var options = ["2:00","3:00","4:00","5:00","6:00","7:00","8:00","9:00","10:00"];
			$("#timerDropDown option").each(function(index){
				$(this).text(options[index]);			
			});
			
			var htmlOptions = [
						"<span aria-hidden='true'>2:00</span><span class='sr-only'>2 Minutes</span>",
						"<span aria-hidden='true'>3:00</span><span class='sr-only'>3 Minutes</span>",
						"<span aria-hidden='true'>4:00</span><span class='sr-only'>4 Minutes</span>",
						"<span aria-hidden='true'>5:00</span><span class='sr-only'>5 Minutes</span>",
						"<span aria-hidden='true'>6:00</span><span class='sr-only'>6 Minutes</span>",
						"<span aria-hidden='true'>7:00</span><span class='sr-only'>7 Minutes</span>",
						"<span aria-hidden='true'>8:00</span><span class='sr-only'>8 Minutes</span>",
						"<span aria-hidden='true'>9:00</span><span class='sr-only'>9 Minutes</span>",
						"<span aria-hidden='true'>10:00</span><span class='sr-only'>10 Minutes</span>"
			];
			
			$("#option-list li").each(function(index){
				$(this).html(htmlOptions[index]);			
			});
		}
		playerObj.audioObj.playAudio(playerObj.audioEleArr[0]);
	}
	
	this.onTimerStartBtnHover = function(){
		var imageName = that.isTimerStarted ? 'pause_btn_over.png' : 'play_btn_over.png'; 
		that.$timerStartBtn.find('img').attr('src','assets/images/'+imageName);
	}
	
	this.onTimerStartBtnOut = function(){
		var imageName = that.isTimerStarted ? 'pause_btn.png' : 'play_btn.png'; 
		that.$timerStartBtn.find('img').attr('src','assets/images/'+imageName);
	}
	
	this.onTimerStartBtnClick = function(){
		console.log('Timer Start button Click');
		
		playerObj.audioObj.playAudio(playerObj.audioEleArr[0]);
		
		if(!that.isTimerStarted){
			that.$timerStartBtn.find('img').attr('src','assets/images/pause_btn.png');
			that.$timerStartBtn.find('.timer-start-text').html('Pause');
			that.isTimerStarted = true;
			
			//that.remainingMinutes = parseInt( that.$timerDropDown.val() );
			//that.selectedIndex = $("#timerDropDown").prop('selectedIndex');
			that.selectedIndex = Number( $("#option-list li[aria-selected='true']").attr('id').split('_')[1] ) - 1;
			that.remainingMinutes = parseInt( $("#option-list li[aria-selected='true'] span[aria-hidden='true']").text() );
			
			//$("#dynamicContent").html('Pause');
			
			$(this).attr('aria-pressed',true);
			
			clearInterval(that.timerIntervalID);
			that.timerIntervalID = setInterval(that.onTimerUpdate,1000);
			
			//that.$timerDropDown.attr('disabled','disabled');
			
		}else{
			that.$timerStartBtn.find('img').attr('src','assets/images/play_btn.png');
			that.$timerStartBtn.find('.timer-start-text').html('Start');
			that.isTimerStarted = false;
			
			//$("#dynamicContent").html('Start');
			
			$(this).attr('aria-pressed',false);
			
			clearInterval(that.timerIntervalID);
			
			//that.$timerDropDown.removeAttr('disabled','disabled');
		}
	}

	this.onTimerUpdate = function(){
		if(that.remainingSeconds > 0){
			
			if(that.remainingSeconds == 60){
				$("#dynamicContent").html(that.remainingMinutes+"  Minutes are remaining");
				that.remainingMinutes--;
			}
			that.remainingSeconds--;
			
			if( (that.remainingMinutes == 0) && (that.remainingSeconds == 3) ){	
				playerObj.audioObj.playAudio(playerObj.audioEleArr[1]);
			}
			
			if( (that.remainingMinutes == 0) && (that.remainingSeconds == 0) ){	
				clearInterval(that.timerIntervalID);
				that.isTimerStarted = false;
				that.isPlayBtnDisabled = true;
				that.$timerStartBtn.attr('disabled','disabled');
				that.$timerStartBtn.find('img').attr('src','assets/images/play_btn.png');
				that.$timerStartBtn.find('.timer-start-text').html('Play');
				that.$timerStartBtn.css('opacity',0.5);
			}
			
			if(String(that.remainingSeconds).length == 2){
				var tmpStr = "<span aria-hidden='true'>"+that.remainingMinutes+":"+that.remainingSeconds+"</span><span class='sr-only'>"+that.remainingMinutes+" Minutes "+that.remainingSeconds+" Seconds</span>";
				$("#timer-button").html(tmpStr);
				//$("#timerDropDown option:eq("+that.selectedIndex+")").text(that.remainingMinutes+":"+that.remainingSeconds);
				//$("#timerDropDown option:eq("+that.selectedIndex+")").attr('aria-label',that.remainingMinutes+' Minutes and '+that.remainingSeconds+' Seconds');
				//$("#timer .current-timer-value").text(that.remainingMinutes+":"+that.remainingSeconds);
				//that.$timerDropDown.find('.dropdown-toggle').html(that.remainingMinutes+":"+that.remainingSeconds);
			}else{
				var tmpStr = "<span aria-hidden='true'>"+that.remainingMinutes+":0"+that.remainingSeconds+"</span><span class='sr-only'>"+that.remainingMinutes+" Minutes "+that.remainingSeconds+" Seconds</span>";
				$("#timer-button").html(tmpStr);
				//$("#timerDropDown option:eq("+that.selectedIndex+")").text(that.remainingMinutes+":0"+that.remainingSeconds);
				//$("#timerDropDown option:eq("+that.selectedIndex+")").attr('aria-label',that.remainingMinutes+' Minutes and '+that.remainingSeconds+' Seconds');
				//$("#timer .current-timer-value").text(that.remainingMinutes+":0"+that.remainingSeconds);
				//that.$timerDropDown.find('.dropdown-toggle').html(that.remainingMinutes+":"+that.remainingSeconds);
			}
				
		}else{
			that.remainingSeconds = 60;
		}
		//console.log(that.remainingMinutes,that.remainingSeconds);
	}	
	
	this.onTimerResetBtnClick = function(){
		console.log('Timer Reset button Click');
		var options = ["2:00","3:00","4:00","5:00","6:00","7:00","8:00","9:00","10:00"];
		clearInterval(that.timerIntervalID);
		playerObj.audioObj.playAudio(playerObj.audioEleArr[0]);
		that.$timerStartBtn.find('img').attr('src','assets/images/play_btn.png');
		that.$timerStartBtn.find('.timer-start-text').html('Start');
		that.isTimerStarted = false;
		that.remainingMinutes = 10;
		that.remainingSeconds = 60;
		$("#timerDropDown option").each(function(index){
			//console.log(options[index]);
			$(this).text(options[index]);
			//$(this).attr('aria-label',parseInt(options[index])+' Minutes');
		});
		
		$("#option-list li").each(function(index){
			$(this).html(htmlOptions[index]);			
		});
		
		$("#timer-button").html(htmlOptions[that.selectedIndex]);
		
		that.$timerDropDown.prop('selectedIndex',that.selectedIndex)
		that.$timerStartBtn.attr('aria-pressed',false);
		that.$timerStartBtn.removeAttr('disabled');
		that.$timerStartBtn.css('opacity',1);
		that.isPlayBtnDisabled = false;
		$("#dynamicContent").html('Timer is Reset');
	}
	
	this.onTimerResetBtnHover = function(){
		that.$timerResetBtn.find('img').attr('src','assets/images/reset_btn_over.png');	
	}	
		
	this.onTimerResetBtnOut = function(){
		that.$timerResetBtn.find('img').attr('src','assets/images/reset_btn.png');	
	}
	
	this.showTimer = function(){
		that.isTimerShown = true;
		that.$timer.show();	
	}
		
	this.hideTimer = function(){
		that.isTimerShown = false;
		that.$timer.hide();
	}	
	
	this.resetTimer = function(){
		that.onTimerResetBtnClick();	
		that.hideTimer();
		that.$timerDropDown.find('.dropdown-toggle').html('10:00');
		that.selectedIndex = 8;
		that.$timerDropDown.prop('selectedIndex',that.selectedIndex);
		$("#timer-button").html(htmlOptions[that.selectedIndex]);
		listboxButton.listbox.focusLastItem();
	}
}	