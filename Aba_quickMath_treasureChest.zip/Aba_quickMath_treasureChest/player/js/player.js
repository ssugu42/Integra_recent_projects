var listboxButton;
var QuickMathsPlayer = function(){
	var that = this;
	var totalPreloadCount = 0;
	var curLoadedCount = 0;
	var isKeyEvent = true;
	that.buttonClickSound = 'assets/audio/buttonClick.mp3';
	that.playerTimerEndSound = 'assets/audio/timerEnd.mp3';
	that.audioEle = document.createElement('audio');
	that.activityData = '';
	var isIPAD = (/iPad|iPhone/i.test(navigator.userAgent)); // IPAD
	var isAndroid = navigator.userAgent.toLowerCase().indexOf("android") > -1; //&& ua.indexOf("mobile");
	var isMac = (navigator.appVersion.indexOf("Mac") != -1);
			
	this.init = function(){ 
		console.log('Player Called');
		that.initVars();
		that.loadActivityData();
	}
	
	this.initVars = function(){
		that.$soundBtn = $("#soundBtn");
		that.$timerBtn = $("#timerBtn");
		that.$resetBtn = $("#resetBtn");
		that.$teacherNotesBtn =  $("#teacherNotesBtn");
		
		that.$teacherNotesOverlay = $("#teacherNotesOverlay");
		that.$teacherNotesPopup = $("#teacherNotesPopup");
		that.$teacherNotesCloseBtn = $("#notesCloseBtn");
		
		if(isIPAD || isAndroid || isMac){
			that.$teacherNotesCloseBtn.css({'top':'-11px'});
		}
		
		that.$notesContent = $("#notesContent");
		that.$activityContainer = $("#activityContainer");
		
		that.audioSrcArr = [that.buttonClickSound,that.playerTimerEndSound];
		that.audioEleArr = [$("#playerButtonClick"),$("#playerTimerEndSound")];
		
		that.audioObj = new AudioPlayer();
		that.audioObj.init();
		that.audioObj.loadAudio(that.audioEleArr,that.audioSrcArr);

		that.timerObj = new Timer(that);
		that.timerObj.init();
		
		var button = document.getElementById('timer-button');
		var exListbox = new aria.Listbox(document.getElementById('option-list'));
		listboxButton = new aria.ListboxButton(button, exListbox);
		
		that.addEvents();
	}
	
	this.addEvents = function(){
	    $("#teacherNotesBtn,#timerBtn,#soundBtn,#resetBtn").off('mouseover').on('mouseover',that.onHeaderButtonHover);	
		$("#teacherNotesBtn,#timerBtn,#soundBtn,#resetBtn").off('mouseout').on('mouseout',that.onHeaderButtonOut);

		that.$soundBtn.off('click').on('click',that.toggleSound);	
		that.$timerBtn.off('click').on('click',that.toggleTimer);
		that.$resetBtn.off('click').on('click',that.resetPlayer);
		that.$teacherNotesBtn.off('click').on('click',that.showTeacherNotes);
		that.$teacherNotesCloseBtn.off('click').on('click',that.hideTeacherNotes);
		
		that.addKeyBoardTraps();
		
		$('button,select,#teacherNotesPopup').on('mousedown mouseup',function(e){
			isKeyEvent = false;
			//$(this).blur();
			if (($(this).is(":focus") || $(this).is(e.target) || $(this).is(e.currentTarget)) && $(this).css("outline-style") == "none") {                    
              $(this).css("outline", "none").on("blur", function() {
				  //console.log(isKeyEvent);
				  $(this).off("blur").css("outline", "");
              });
			}
		});
		
		that.$teacherNotesPopup.on('focus',function(){
			if(!isKeyEvent){
				$(this).css("outline", "none").on("blur", function() {
				  isKeyEvent = true;
				  console.log(isKeyEvent);
				  $(this).off("blur").css("outline", "");
				});
				//$("#teacherNotesPopup").css("outline-style", "");
				//isKeyEvent = true;
			}
		});
		
		$(window).on('focus',function(){
			//$('#teacherNotesPopup').blur();
			//isKeyEvent = false;
			//console.log('Window focus',isKeyEvent);
		});
		
		$(window).on('resize',function(){
			that.$teacherNotesOverlay.height( $(document).height() - 25 );
		});
		
		that.$teacherNotesOverlay.height( $(document).height() - 25 );
	}
	
	this.addKeyBoardTraps = function(){
		$(document).on('keydown',function(e){
			var keyCode = e.keyCode;
			
			console.log( keyCode )
			
			if(keyCode == 27 && (that.$teacherNotesPopup.css('display') == 'block') ){
				that.hideTeacherNotes();
			}
			
			if(keyCode != 9){
				return;
			}
			
			if( ( (keyCode == 9 && e.shiftKey) ) && ( document.activeElement == $("#teacherNotesPopup")[0] ) ){
				$("#teacherNotesPopup").focus();
				e.preventDefault();
			}
			
			//console.log( document.activeElement );
			
			if((keyCode == 9 || (keyCode == 9 && e.shiftKey) ) && ( document.activeElement == $("#teacherNotesPopup").find(".notes-close-btn")[0] ) ){
				$("#teacherNotesPopup").focus();
				e.preventDefault();
			}
		});
	}

	this.onHeaderButtonHover = function(){
		$(this).find('.hover-background').show();
	}
	
	this.onHeaderButtonOut = function(){
		$(this).find('.hover-background').hide();	
	}
	
	this.toggleTimer = function(){
		that.audioObj.playAudio(that.audioEleArr[0]);
		if(that.timerObj.isTimerShown){
			that.timerObj.hideTimer();
			$(this).find('.button-text').html('Timer: <strong>show</strong>');	
			$(this).attr('aria-pressed',false);
			//$("#dynamicContent").html('Timer:show');
		}else{
			that.timerObj.showTimer();
			$(this).find('.button-text').html('Timer: <strong>hide</strong>');	
			$(this).attr('aria-pressed',true);
			//$("#dynamicContent").html('Timer:hide');
		}
	}
	
	this.toggleSound = function(){
		var isSoundOff = that.audioObj.isAudioMuted;
		that.audioObj.playAudio(that.audioEleArr[0]);
		if(isSoundOff){
			that.audioObj.unMuteAudio();	
			$(this).find('.button-text').html('Sound: <strong>turn off</strong>');
			$(this).attr('aria-pressed',false);
			//$("#dynamicContent").html('Sound:turn off');
		}else{
			that.audioObj.muteAudio();	
			$(this).find('.button-text').html('Sound: <strong>turn on</strong>');
			$(this).attr('aria-pressed',true);
			//$("#dynamicContent").html('Sound:turn on');
		}
	}
	
	this.showTeacherNotes = function(){
		that.audioObj.playAudio(that.audioEleArr[0]);
		that.$teacherNotesOverlay.show();
		that.$teacherNotesPopup.show();	
		that.$teacherNotesPopup.focus();
	}
	
	this.hideTeacherNotes = function(){
		that.audioObj.playAudio(that.audioEleArr[0]);
		that.$teacherNotesOverlay.hide();
		that.$teacherNotesPopup.hide();	
		that.$teacherNotesBtn.focus();
	}
	
	this.setTeacherNotesContent = function(curContent){
		that.$notesContent.html(curContent);
	}
	

		
	this.resetPlayer = function(e){
		that.timerObj.resetTimer();
		that.audioObj.unMuteAudio();	
		that.audioObj.playAudio(that.audioEleArr[0]);
		that.$soundBtn.find('.button-text').html('Sound: <strong>turn off</strong>');	
		that.$timerBtn.find('.button-text').html('Timer: <strong>show</strong>');	
		that.$teacherNotesOverlay.hide();
		that.$teacherNotesPopup.hide();	
		$("#dynamicContent").html('Activity is Reset');
		that.loadActivityData();
	}
	
	this.loadActivityData = function(){
		$.ajax({
			url : inner + 'assets/data/activity.json',
			dataType:'json',
			success:function(data){
				console.log('Activity data load success!!!');
				console.log(data);
				that.activityData = data;
				that.preloadAssets( that.activityData.preloadAssets );
			},
			error:function(e){
				console.log('Activity data load failed!!!');
			}
		})
		
	}
	
	this.setYearColor = function(curCode){
		switch(curCode){
			case 'NP':
				$(".player-header").addClass('year_NP');
				break;
			case 'AS':
				$(".player-header").addClass('year_AS');
				break;
			case 'MD':
				$(".player-header").addClass('year_MD');
				break;
			case 'SDPM':
				$(".player-header").addClass('year_SDPM');
				break;
			case 'FDPR':
				$(".player-header").addClass('year_FDPR');
				break;
			case 'AL':
				$(".player-header").addClass('year_AL');
				break;
			case 'MO':
				$(".player-header").addClass('year_MO');
				break;
			case 'dt':
				$(".player-header").addClass('year_dt');
				break;
				
			default:
		}
	}
	
	this.preloadAssets = function(preloadArr){
		curLoadedCount = 0;
		totalPreloadCount = preloadArr.length;
		for(var i=0;i<preloadArr.length;i++){
			var imageObj = new Image();
			imageObj.src = inner + preloadArr[i];
			imageObj.addEventListener('load',that.onImageLoad,false);
			imageObj.addEventListener('error',that.onImageLoad,false);
		}
	}
	
	this.onImageLoad = function(){
		curLoadedCount++;
		//console.log(curLoadedCount,totalPreloadCount);
		if(curLoadedCount == totalPreloadCount){
			$("#preloader").hide();
			$("#player").show();
			if(that.activityData.startScreen.gameTopic != ""){
				$("#activityTitle").html(that.activityData.startScreen.gameTopic);
			}else{
				$("#activityTitle").html(that.activityData.startScreen.gameName);
			}
			that.setYearColor(that.activityData.activityYear);
			that.setTeacherNotesContent(that.activityData.teacherNotes);
			that.loadActivity();
		}
	}
	
	this.getTemplatePath = function(templateCode){
		var templatePath = '';
		switch(templateCode){
			case 'CC':
				templatePath = 'templates/careless_cat/';
				break;
			case 'SP':
				templatePath = 'templates/star_pairs/';
				break;
		}
		
		return templatePath;
	}
	
	this.loadActivity = function(){
		//var curTemplatePath = that.getTemplatePath(that.activityData.templateCode);
		var curTemplatePath = '';
		console.log(curTemplatePath);
		//that.$activityContainer.load(curTemplatePath+'index.html',function(){
		that.$activityContainer.load(inner+curTemplatePath+'index.html',function(){
			var activityObj = new quickMathsActivity(that);
			activityObj.init();
		});	
	}
}